split :: [a]->([a],[a])

merge :: ([a],[a])->[a]